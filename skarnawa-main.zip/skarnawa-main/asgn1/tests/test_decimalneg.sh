# Creates the example output
echo "BAD INPUT" > exout.txt

# Runs the program
./calc 1 5.4 > calc.txt 

# Ensures exit code is Zero

# Ensures differences *are* found
diff exout.txt calc.txt
if [ $? -ne 0 ]; then
    echo "BAD INPUT"
    rm exout.txt
    rm calc.txt
    exit 1
fi


#makes sure that number input is not greater than 512


# Prints a message on success
# Cleans up files created
rm exout.txt
rm calc.txt
exit 0
