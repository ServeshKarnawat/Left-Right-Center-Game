# Creates the example output
echo "BAD INPUT" > exout.txt

# Runs the program
./calc 5 a> calc.txt 

# Ensures exit code is Zero

# Ensures differences *are* found
diff exout.txt calc.txt
if [ $? -ne 0 ]; then
    echo "Somehow, the output of 512+512 is not 1024!"
    rm exout.txt
    rm calc.txt
    exit 1
fi


#makes sure that number input is not greater than 512


# Prints a message on success
echo "Test found 512 512 = 1024: PASS"

# Cleans up files created
rm exout.txt
rm calc.txt
exit 0
