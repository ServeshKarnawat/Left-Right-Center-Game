# Creates the example output
echo "BAD INPUT" > exout.txt

# Runs the program
./calc - 2 > calc.txt 





# Ensures differences *are* found
diff exout.txt calc.txt
if [ $? -ne 0 ]; then
    echo "NOT ENOUGH INPUT"
    rm exout.txt
    rm calc.txt
    exit 1
fi


#makes sure that number input is not greater than 512


# Prints a message on success

# Cleans up files created
rm exout.txt
rm calc.txt
exit 0
