# Creates the example output
echo "TOO BIG" > exout.txt

# Runs the program
./calc 5 1000 > calc.txt 





# Ensures differences *are* found
diff exout.txt calc.txt
if [ $? -ne 0 ]; then
    echo "TOO BIG"
    rm exout.txt
    rm calc.txt
    exit 1
fi


#makes sure that number input is not greater than 512


# Prints a message on success

# Cleans up files created
rm exout.txt
rm calc.txt
exit 0
