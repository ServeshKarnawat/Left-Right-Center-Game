#include "hangman_helpers.h"

#include <stdio.h>
char *secret;

int main(int argc, char *argv[]) {
    secret = argv[argc - 1];
    if (!(is_valid_secret(secret))) {

        return 1;
    }

    char correct[((int) strlen(secret)) + 1];
    char elimanated[28];
    char *currentPhrase = setPhrase(secret, correct);
    int tries = 0;
    char currentGuess;
    int i;
    int check = 1;
    int timesRan = 0;
    int solved = 1;

    if (string_contains_character(currentPhrase, '_')) {
        solved = 1;

    } else {
        solved = 0;
    }

    //game loop
    while (tries < 6 && solved == 1) {

        printf("%s", arts[tries]);
        printf("\n");
        //print the letters currently in
        printf("    Phrase: ");

        for (i = 0; i < (int) strlen(secret); i++) {
            printf("%c", currentPhrase[i]);
        }
        printf("\n");

        //this goes through and updates the elimanated letters
        printf("Eliminated: ");

        for (i = 97; i < 123; i++) {
            if (string_contains_character(elimanated, (char) i)) {
                printf("%c", (char) i);
            }
        }
        printf("\n");
        printf("\n");
        //make sure input is valid letter or else ask again
        check = 1;
        currentGuess = read_letter();
        while (check == 1) {
            if (!(is_lowercase_letter(currentGuess))) {
                currentGuess = read_letter();
            } else if (string_contains_character(elimanated, currentGuess)) {
                currentGuess = read_letter();
            } else if (string_contains_character(currentPhrase, currentGuess)) {
                currentGuess = read_letter();
            } else {
                check = 0;
            }
        }

        //if the letter guessed is not already in the list add it
        //if(!(string_contains_character(elimanated, currentGuess))){
        //	elimanated[timesRan] = currentGuess;
        //	}
        //if they get a letter wrong add to tries
        //if it is right update the log

        if (string_contains_character(secret, currentGuess)) {
            currentPhrase = phrase(secret, currentPhrase, currentGuess);

        } else {
            elimanated[timesRan] = currentGuess;
            tries = tries + 1;
            timesRan = timesRan + 1;
        }

        //check if solved
        if (string_contains_character(currentPhrase, '_')) {
            solved = 1;

        } else {
            solved = 0;
        }
    }

    printf("%s", arts[tries]);
    printf("\n");
    //print the letters currently in
    printf("    Phrase: ");

    for (i = 0; i < (int) strlen(secret); i++) {
        printf("%c", currentPhrase[i]);
    }
    printf("\n");

    //this goes through and updates the elimanated letters
    printf("Eliminated: ");

    for (i = 97; i < 123; i++) {
        if (string_contains_character(elimanated, (char) i)) {
            printf("%c", (char) i);
        }
    }
    printf("\n");
    printf("\n");

    if (solved == 0) {
        printf("You win! The secret phrase was: %s\n", secret);
    } else {
        printf("You lose! The secret phrase was: %s\n", secret);
    }

    return 0;
}
