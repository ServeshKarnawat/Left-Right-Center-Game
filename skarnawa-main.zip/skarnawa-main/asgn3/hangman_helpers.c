#include "hangman_helpers.h"

#include <string.h>

bool is_lowercase_letter(char c) {
    if ((int) c >= 97 && (int) c <= 122) {
        return true;
    } else {
        return false;
    }
}
char *setPhrase(const char *secret, char *correct) {
    int i;
    for (i = 0; i < (int) strlen(secret); i++) {
        if (secret[i] == '\'') {
            correct[i] = '\'';
        } else if (secret[i] == ' ') {
            correct[i] = ' ';
        } else if (secret[i] == '-') {
            correct[i] = '-';
        } else {
            correct[i] = '_';
        }
    }
    return correct;
}

char *phrase(const char *secret, char *correct, char input) {
    int i;
    for (i = 0; i < (int) strlen(secret); i++) {
        if (input == secret[i]) {
            correct[i] = secret[i];
        }
    }
    return correct;
}

bool is_valid_secret(const char *secret) {
    int i;
    for (i = 0; i <= (int) strlen(secret); i++) {
        if (is_lowercase_letter(secret[i]) || (int) secret[i] == 0 || (int) secret[i] == 32
            || (int) secret[i] == 45 || (int) secret[i] == 39) {
            if (i > 256) {
                fprintf(stdout, "the secret phrase is over 256 characters\n");

                return false;
            }
        } else {
            fprintf(stdout, "invalid character: '%c'\n", secret[i]);
            printf("the secret phrase must contain only lowercase letters, spaces, hyphens, and "
                   "apostrophes\n");

            return false;
        }
    }

    return true;
}

bool string_contains_character(const char *s, char c) {
    int i;
    for (i = 0; i < (int) (strlen(s)); i++) {
        if (c == s[i]) {
            return true;
        }
    }
    return false;
}

char read_letter(void) {
    char letter;
    printf("Guess a letter: ");
    scanf("%c", &letter);
    while (getchar() != '\n')
        ;
    return letter;
}
