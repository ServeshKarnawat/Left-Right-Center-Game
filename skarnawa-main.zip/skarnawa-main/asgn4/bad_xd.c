#include<fcntl.h>
#include<stdio.h>
#include<unistd.h>
int main(int argc, char **argv) {int fd;ssize_t res;char buffy[16];if(argc<2){fd=0;res=read(fd,buffy,16);while(res<16){ssize_t res2=read(fd,buffy+res,(size_t)(16-res));if(res2>0){res+=res2;}else{break;}}}else{char *fileName=argv[argc-1];fd=open(fileName,O_RDONLY);res=read(fd,buffy,16);}if(fd==-1){return 1;}int i;int j=0;while(res!=0){i=0;printf("%08x: ",j);for(i=0;i<16;i++){if(i>0&&i%2==0){printf(" ");}if(i<res){printf("%02hhx",buffy[i]);if((int)buffy[i]<32||(int)buffy[i]>126){buffy[i] = '.';}}else{printf("  ");}}printf("  %.*s\n",(int)res,buffy);j+=res;res=read(fd,buffy,16);if(fd==0){while(res<16){ssize_t res2=read(fd,buffy+res,(size_t)(16-res));if(res2>0){res+=res2;}else{break;}}}}return 0;}
