#include "mathlib.h"
#include "messages.h"
#include "operators.h"
#include "stack.h"

#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {

    if (strcmp(argv[argc - 1], "-h") == 0) {
        printf(" to run this program type './calc'. once you run that type the operation you want "
               "to run in rcd notation. for exampe 3 + 4 is written 3 4 +");
    }

    //get the input using fgets
    char equation[STACK_CAPACITY];
    int running = 0;
    while (running == 0) {
        fprintf(stderr, "> ");

        if (fgets(equation, STACK_CAPACITY, stdin) == NULL) {
            running = 1;
        }
        bool problems = true;

        int j = 0;
        char *new_equation[STACK_CAPACITY];
        //split string and save all thing into an array
        char *phrase = strtok(equation, " ");
        while (phrase != NULL) {
            new_equation[j] = phrase;
            phrase = strtok(NULL, " ");
            j++;
        }
        int length = j;
        double num;
        //double lhs;
        //double rhs;
        // now new_equation has all the values in it
        for (j = 0; j < length; j++) {
            //	printf("stack print: ");
            //	stack_print();
            //	printf("next letter: %s\n", new_equation[j]);

            if (parse_double(new_equation[j], &num)) {
                stack_push(num);
            } else {

                if (strcmp(new_equation[j], "+\n") == 0) {
                    new_equation[j] = "+";
                }

                if (strcmp(new_equation[j], "-\n") == 0) {
                    new_equation[j] = "-";
                }

                if (strcmp(new_equation[j], "*\n") == 0) {
                    new_equation[j] = "*";
                }

                if (strcmp(new_equation[j], "/\n") == 0) {
                    new_equation[j] = "/";
                }

                if (strcmp(new_equation[j], "%\n") == 0) {
                    new_equation[j] = "%";
                }

                if (strcmp(new_equation[j], "s\n") == 0) {
                    new_equation[j] = "s";
                }

                if (strcmp(new_equation[j], "t\n") == 0) {
                    new_equation[j] = "t";
                }

                if (strcmp(new_equation[j], "c\n") == 0) {
                    new_equation[j] = "c";
                }

                if (strcmp(new_equation[j], "a\n") == 0) {
                    new_equation[j] = "a";
                }

                if (strcmp(new_equation[j], "r\n") == 0) {
                    new_equation[j] = "r";
                }

                if (strcmp(new_equation[j], "+") == 0 || strcmp(new_equation[j], "-") == 0
                    || strcmp(new_equation[j], "*") == 0 || strcmp(new_equation[j], "/") == 0
                    || strcmp(new_equation[j], "%") == 0) {

                    //stack_pop(&rhs);
                    //stack_pop(&lhs);#define ERROR_BINARY_OPERATOR
                    problems = apply_binary_operator(binary_operators[(int) *new_equation[j]]);

                } else if (strcmp(new_equation[j], "s") == 0 || strcmp(new_equation[j], "c") == 0
                           || strcmp(new_equation[j], "t") == 0 || strcmp(new_equation[j], "a") == 0
                           || strcmp(new_equation[j], "r") == 0) {
                    //stack_pop(&rhs);
                    problems = apply_unary_operator(my_unary_operators[(int) *new_equation[j]]);
                } else {
                    if (strlen(new_equation[j]) == 1) {
                        fprintf(stderr, "error: unknown operation '%s'\n", new_equation[j]);
                    } else {
                        fprintf(stderr, "error: unknown operation \"%s\"\n", new_equation[j]);
                    }
                }
            }
        }

        if (running == 0 && problems) {
            stack_print();
        }
        stack_clear();
    }
    /*
	int i;
	for (i=0, i<strlen(equation), i++){
	
		while(
	}
	bool opperators_left = true;
	double num;
	while(i<(argc-1)){
	
		if(parse_double(argv[i], num)){
		
			stack_push(num);
		}
		else{
			if(argv[i]== "+" || argv[i]== "-" ||argv[i]== "*" ||argv[i]== "/" ||argv[i]== "%"){
		
				apply_binary_operator(argv[i]);
			}
			else if (argv[i]== "s" ||argv[i]== "c" ||argv[i]== "t" ||argv[i]== "a" ||argv[i]== "r" ){
				apply_unary_operator(argv[i]);
			}
			else{
				return 1;
		}

	}
		i++;
	}

	*/
    return 0;
}
