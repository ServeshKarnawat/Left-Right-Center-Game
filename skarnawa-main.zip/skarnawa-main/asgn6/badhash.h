#ifndef _BADHASH_H
#define _BADHASH_H
#include <stdlib.h>

size_t hashconfig(char *);

#endif // _BADHASH_H
