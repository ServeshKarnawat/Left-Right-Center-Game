#ifndef _HASH

#define _HASH

#include "badhash.h"
#include "ll.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Hashtable Hashtable;
struct Hashtable {
    LL *bucket[50];
};

Hashtable *hash_create(void) {

    Hashtable *table = calloc(1, sizeof(Hashtable));
    if (table == NULL) {
        return NULL;
    }
    for (int i = 0; i < 50; i++) {
        table->bucket[i] = list_create();
    }
    return table;
}

bool hash_put(Hashtable *table, char *key, int val) {

    int index = hashconfig(key) % 50;
    LL *l = table->bucket[index];

    item i;

    i.id = val;
    strncpy(i.key, key, 225);
    return list_add(l, &i);
}
int *hash_get(Hashtable *table, char *key) {

    int index = hashconfig(key) % 50;
    LL *l = table->bucket[index];
    item i;
    strncpy(i.key, key, 225);
    item *found_item = list_find(l, cmp, &i);
    if (found_item == NULL) {
        return NULL;
    }
    return &found_item->id;
}

void hash_destroy(Hashtable **tableP) {
    if (tableP == NULL || *tableP == NULL) {
        return;
    }
    Hashtable *table = *tableP;

    for (int i = 0; i < 50; i++) {
        LL *l = table->bucket[i];
        /*Node *c = l->head;
		while (c != NULL){
			Node *next = c->next;
			free(c);
			c = next;
		}*/
        list_destroy(&l);
    }
    free(table);
    *tableP = NULL;
}
#endif //_HASH
