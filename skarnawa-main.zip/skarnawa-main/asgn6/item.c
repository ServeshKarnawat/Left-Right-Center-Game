#include "item.h"

#include <stdio.h>
#include <string.h>

// implementation of the cmp() function on items, for when items are ints
bool cmp(item *i1, item *i2) {
    if (i2 == NULL || i2 == NULL) {
        return false;
    }
    return !strcmp(i1->key, i2->key);
}
