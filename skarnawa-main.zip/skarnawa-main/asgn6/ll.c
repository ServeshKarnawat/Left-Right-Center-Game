#include "ll.h"

#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

LL *list_create(void) {
    LL *l = (LL *) calloc(1, sizeof(LL));
    if (l == NULL) {
        return NULL;
    }
    l->head = NULL;
    l->tail = NULL;
    return l;
}

bool list_add(LL *l, item *i) {
    Node *n = (Node *) calloc(1, sizeof(Node));
    if (n == NULL) {
        return false;
    }
    n->data = *i;
    n->next = NULL;
    //if empty list
    if (l->head == NULL) {
        l->head = n;
        l->tail = n;
    }
    //not empty list
    else {
        l->tail->next = n;
        l->tail = n;
    }
    return true;
}

item *list_find(LL *l, bool (*cmpfn)(item *, item *), item *i) {
    Node *n = l->head;
    while (n != NULL) {
        if (cmpfn(&n->data, i)) {
            return &n->data;
        }
        n = n->next;
    }
    return NULL;
}

void list_destroy(LL **ll) {
    if (ll == NULL || *ll == NULL) {
        return;
    }
    Node *current = (*ll)->head;
    Node *next = NULL;

    while (current != NULL) {
        next = current->next;
        free(current);
        current = next;
    }

    if ((*ll)->tail != NULL) {
        (*ll)->tail = NULL;
    }
    if ((*ll)->head != NULL) {
        (*ll)->head = NULL;
    }

    free(*ll);

    *ll = NULL;
}
void list_remove(LL *ll, bool (*cmpfn)(item *, item *), item *iptr) {
    if (ll == NULL || ll->head == NULL) {
        return;
    }
    Node *n = ll->head;
    Node *prev = NULL;
    while (n != NULL) {
        if (cmpfn(&n->data, iptr)) {
            //first value case
            if (prev == NULL) {
                //only value
                if (ll->head == ll->tail) {
                    ll->tail = NULL;
                }
                ll->head = n->next;
            }
            //not first value
            else {
                //last element removed
                if (n == ll->tail) {
                    ll->tail = prev;
                }
                //regular
                prev->next = n->next;
            }
            free(n);
            return;
        }
        prev = n;
        n = n->next;
    }
}
