#include "hash.h"
#include "item.h"
#include "ll.h"

#include <stdio.h>
#include <string.h>

int main() {

    //store the word
    char equation[100];
    //loop condition
    int running = 0;

    int total = 0;
    Hashtable *table = hash_create();
    while (running == 0) {

        if (fgets(equation, 100, stdin) == NULL) {
            running = 1;
        }

        if (strcmp(equation, "\n") != 0) {

            if (hash_get(table, equation) == NULL) {

                total++;
            }

            hash_put(table, equation, 1);
        }
    }
    printf("%d\n", total);

    hash_destroy(&table);
    return 0;
}
