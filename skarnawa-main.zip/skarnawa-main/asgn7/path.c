#include "path.h"

#include "graph.h"
#include "stack.h"

#include <inttypes.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
struct path;
typedef struct path {
    uint32_t total_weight;
    Stack *vertices;
} Path;

Path *path_create(uint32_t capacity) {
    Path *p = (Path *) calloc(1, sizeof(Path));
    if (!p) {
        return NULL;
    }
    p->total_weight = 0;

    p->vertices = stack_create(capacity);
    if (!p->vertices) {
        free(p);
        return NULL;
    }
    return p;
}

void path_free(Path **pp) {
    if (pp != NULL && *pp != NULL) {
        if ((*pp)->vertices) {
            stack_free(&(*pp)->vertices);
        }
        free(*pp);
    }

    if (pp != NULL) {
        *pp = NULL;
    }
}

uint32_t path_vertices(const Path *p) {
    return (stack_size(p->vertices));
}

uint32_t path_distance(const Path *p) {
    return p->total_weight;
}

void path_add(Path *p, uint32_t val, const Graph *g) {
    //get current value in stack and if it is empty save that
    uint32_t prev;
    bool empty;
    empty = stack_peek(p->vertices, &prev);
    //add new value to stack

    stack_push(p->vertices, val);
    //graph_visit_vertex(g, val);
    // save that value
    if (empty) {
        uint32_t added;
        stack_peek(p->vertices, &added);
        //get the weight and add it to total weight
        p->total_weight = (p->total_weight + graph_get_weight(g, prev, added));
    }
}
uint32_t path_remove(Path *p, const Graph *g) {
    uint32_t end;

    stack_pop(p->vertices, &end);

    //graph_unvisit_vertex(g, stack_size(p->vertices));
    if (!stack_empty(p->vertices)) {
        uint32_t start;

        stack_peek(p->vertices, &start);
        p->total_weight = (p->total_weight - graph_get_weight(g, start, end));
    }

    return end;
}

void path_copy(Path *dst, const Path *src) {
    stack_copy(dst->vertices, src->vertices);
    dst->total_weight = src->total_weight;
}
void path_print(const Path *p, FILE *f, const Graph *g) {
    stack_print(p->vertices, f, graph_get_names(g));
}
