#include "graph.h"
#include "path.h"
#include "stack.h"

#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

void dfs(Graph *g, uint32_t root, Path *current, Path *shortest) {
    //visit first node and push it to path
    path_add(current, root, g);
    graph_visit_vertex(g, root);
    //base case
    if (path_vertices(current) == graph_vertices(g)) {
        //if there is edge connecting current vertex to og root means cycle

        if (graph_get_weight(g, root, 0) != 0) {
            path_add(current, 0, g);
            if (path_distance(current) < path_distance(shortest) || path_distance(shortest) == 0) {

                path_copy(shortest, current);
            }
            path_remove(current, g);
        }
    }
    for (uint32_t i = 0; i < graph_vertices(g); i++) {
        if (graph_get_weight(g, root, i) > 0) {
            if (!graph_visited(g, i)) {
                dfs(g, i, current, shortest);
            }
        }
    }
    graph_unvisit_vertex(g, root);
    path_remove(current, g);
}

int main(int argc, char *argv[]) {

    //get the input to see if we input output etc
    int opt;
    bool direct = false;
    FILE *input = stdin;
    FILE *output = stdout;
    while ((opt = getopt(argc, argv, "dhi:o:")) != -1) {
        switch (opt) {
        case 'd': direct = true; break;
        case 'i': input = fopen(optarg, "r"); break;
        case 'o': output = fopen(optarg, "w"); break;
        case 'h': printf("type something"); break;
        }
    }
    if (input == NULL) {
        fprintf(stderr, "no path found\n");
        exit(0);
    }
    if (output == NULL) {
        fprintf(stderr, "no path found.\n");
        exit(0);
    }

    int capacity = 50;

    uint32_t counter;
    char line[capacity];
    //see first line and set loop up
    //if there is nothing then leave
    if (fgets(line, capacity, input) == NULL) {
        fprintf(stderr, "tsp: error reading number of vertices\n");
        exit(0);
    }

    counter = (uint32_t) strtoul(line, NULL, 10);
    Graph *g = graph_create(counter, direct);
    Stack *s = stack_create(counter);
    Path *current = path_create(counter + 1);
    Path *fastest = path_create(counter + 1);

    //now we can put in the following lines into the graph
    for (uint32_t i = 0; i < counter; i++) {

        fgets(line, capacity, input);
        line[strcspn(line, "\n")] = '\0';
        graph_add_vertex(g, line, i);
    }
    //now get how many edges
    if (fgets(line, capacity, input) == NULL) {
        return 1;
    }
    //about to go through each of the edges
    counter = (uint32_t) strtoul(line, NULL, 10);

    //split the string into the 3 different parts
    int j;
    uint32_t new_equation[3];
    for (uint32_t i = 0; i < counter; i++) {
        j = 0;
        fgets(line, capacity, input);
        char *phrase = strtok(line, " ");
        while (phrase != NULL) {

            //each index 0-2 is one of the numbers
            new_equation[j] = (uint32_t) strtoul(phrase, NULL, 10);
            phrase = strtok(NULL, " ");
            j++;
        }
        //after 0 1 5 type of line is read add it to graph
        graph_add_edge(g, new_equation[0], new_equation[1], new_equation[2]);
    }

    //start the recursion dfs
    dfs(g, 0, current, fastest);

    if (fastest == NULL || path_distance(fastest) == 0) {
        fprintf(stderr, "No path found! Alissa is lost!\n");
        exit(0);
    }

    fprintf(output, "Alissa starts at:\n");

    path_print(fastest, output, g);

    fprintf(output, "Total Distance: %u\n", path_distance(fastest));

    if (input != stdin) {
        fclose(input);
    }
    if (output != stdout) {
        fclose(output);
    }
    stack_free(&s);
    graph_free(&g);
    path_free((&current));
    path_free((&fastest));
    return 0;
}
