/*
* DO NOT MODIFY THIS FILE.
*/

#pragma once

#define START_VERTEX 0 // Starting (origin) vertex
